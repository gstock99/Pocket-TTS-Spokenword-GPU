# Configuration system for audiobook generation

import os
import json
from pathlib import Path
from typing import Dict, Any, Optional, List
try:
    from ..preprocessing.schema import Config
except ImportError:
    # Fallback for testing
    from preprocessing.schema import Config

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False
    yaml = None

class ConfigManager:
    """Manages configuration loading and validation."""

    DEFAULT_CONFIG = {
        # AUDIOBOOK GENERATION CONFIGURATION

        # CHUNKING SETTINGS - Used in: SmartChunker class
        'chunking': {
            'mode': 'paragraph',  # "sentence" or "paragraph"
            'min_words': 35,      # Minimum words per chunk (GPU-optimized)
            'max_words': 175,     # Maximum words per chunk (GPU-optimized)
            'respect_boundaries': True
        },

        # DEVICE SETTINGS - Used in: TTSModel, AudiobookGenerator
        'device': {
            'auto': True,             # Auto-detect CUDA if available
            'preferred': 'cuda',      # "cpu", "cuda", or "auto"
            'max_nb_tokens_in_a_chunk': 50  # Internal token limit per chunk
        },

        # TTS CORE PARAMETERS - Used in: TTSModel class
        'tts_core': {
            'temperature': 0.85,           # Sampling temperature (0.0-1.5)
            'eos_threshold': -3.0,        # End-of-sequence threshold
            'frames_after_eos': 2         # Frames to generate after EOS detection
        },

        # EMOTION ANALYSIS - Used in: EmotionAnalyzer class
        'emotion': {
            'model': 'j-hartmann/emotion-english-distilroberta-base',
            'mappings': {
                'joy': {'temperature': 0.90, 'speed_factor': 1.00},
                'surprise': {'temperature': 0.85, 'speed_factor': 1.10},
                'anger': {'temperature': 0.80, 'speed_factor': 1.10},
                'neutral': {'temperature': 0.70, 'speed_factor': 1.0},
                'sadness': {'temperature': 0.65, 'speed_factor': 0.85},
                'fear': {'temperature': 0.60, 'speed_factor': 0.90},
                'disgust': {'temperature': 0.65, 'speed_factor': 0.95}
            },
            'keyword_boosts': {
                'joy': {
                    'keywords': ['ecstatic', 'thrilled', 'delighted'],
                    'temperature_boost': 0.03,
                    'speed_boost': 0.02
                },
                'anger': {
                    'keywords': ['enraged', 'infuriated', 'outraged'],
                    'temperature_boost': 0.05,
                    'speed_boost': 0.03
                }
            }
        },

        # PAUSE DURATIONS - Used in: ParameterMapper.calculate_pause()
        'pauses': {
            'base_durations': {
                'sentence_end': 160,      # ms
                'paragraph_break': 320,   # ms
                'chapter_start': 800,     # ms
                'question_mark': 240,     # ms
                'exclamation': 80,        # ms
                'ellipsis': 320           # ms
            },
            'emotion_multipliers': {
                'anger': 1.3,     # Angry pauses are 30% longer
                'fear': 1.2,      # Fearful pauses 20% longer
                'sadness': 1.4,   # Sad pauses 40% longer
                'joy': 0.9,       # Joyful pauses 10% shorter
                'neutral': 1.0    # Baseline
            }
        },

        # PAUSE INJECTION - Used in: pause_injector.inject_pauses_for_punctuation()
        'pause_injection': {
            'enabled': True,
            'punctuation_durations': {
                '.': 0.50,
                '!': 0.25,
                '?': 0.35,
                ',': 0.18,
                '...': 0.40,
                '--': 0.25,
                ';': 0.20,
                ':': 0.20,
                '[0s]': 0.40,     # seconds
                '[1s]': 1.00,     # seconds
                '[2s]': 2.00,     # seconds
                '[3s]': 3.00,     # seconds
                '[4s]': 4.00,     # seconds
                '[5s]': 5.00,	  # seconds
            }
        },

        # SPEED VARIATION - Used in: ParameterMapper
        'speed_variation': {
            'enabled': True,                    # Toggle on/off
            'method': 'librosa',               # "librosa" or "scipy"
            'range': 0.10,                     # ±10% variance
            'emotion_speed_modifiers': {
                'joy': 0.15,
                'surprise': 0.10,
                'anger': 0.10,
                'sadness': -0.15,
                'fear': -0.10,
                'disgust': -0.05,
                'neutral': 0.0
            }
        },

        # M4B CONVERSION - Used in: WavToM4bConverter class
        'm4b': {
            'enabled': False,                  # Enable automatic conversion
            'speed': 1.0,                      # Playback speed multiplier
            'sample_rate': 22050,              # Output sample rate in Hz
            'normalization_type': 'peak',      # "none", "peak", "loudness", "simple"
            'target_db': -1.5                  # Target peak level in dB
        },

        # SHORT SENTENCE MITIGATION - Used in: ParameterMapper class
        'mitigation': {
            'short_sentence_threshold': 5,        # Max words to trigger mitigation
            'temperature_short_sentence': 0.5     # Override temperature for short sentences
        },

        # PARALLEL PROCESSING - Used in: AudiobookGenerator class
        'parallel': {
            'enabled': True,                      # Enable parallel processing
            'max_workers': 6,                     # Sets default in GUI (GPU: each worker loads own model)
            'min_workers': 1,                     # Minimum workers (fallback to sequential)
            'ram_limit_percent': 85,              # RAM usage threshold (%) (GPU shift: less CPU RAM needed)
            'load_threshold': 8.0,                # System load threshold (normalized)
            'adaptive_workers': False             # Adaptive worker count (disabled for testing)
        },

        # ASR QUALITY CONTROL - Used in: ASR integration
        'asr_quality_control': {
            'enabled': False,                     # Enable ASR quality control
            'asr_threshold': 0.75,                # Minimum ASR confidence threshold
            'max_retries': 3,                     # Maximum regeneration attempts per chunk
            'temp_decrement': 0.1                 # Temperature reduction per retry
        },

        # GUI SETTINGS - Used in: MainWindow class
        'gui': {
            'theme': 'system',          # "light", "dark", or "system"
            'auto_save_interval': 30,   # Seconds between progress saves
            'max_preview_chunks': 50,   # How many chunks to show in preview
            'default_output_format': 'wav'  # "wav" or "mp3"
        },

        # DEBUG & DEVELOPMENT SETTINGS
        'debug': {
            'log_level': 'INFO',        # DEBUG, INFO, WARNING, ERROR
            'save_intermediate': False, # Save temp files for debugging
            'profile_performance': False # Enable performance profiling
        },

        # QUALITY SETTINGS
        'quality': {
            'lsd_steps': 2  # Lagrangian Self Distillation steps (1-30; 5-10 optimal)
        }
    }

    @classmethod
    def load_config(cls, config_path: Optional[str] = "pocket_tts/config/default_config.yaml") -> Config:
        """
        Load configuration from file or use defaults.

        Args:
            config_path: Path to config file, or None for defaults

        Returns:
            Config: Validated configuration object
        """
        config_data = cls.DEFAULT_CONFIG.copy()

        if config_path and os.path.exists(config_path):
            try:
                if HAS_YAML and config_path.endswith(('.yaml', '.yml')):
                    with open(config_path, 'r') as f:
                        user_config = yaml.safe_load(f)
                elif config_path.endswith('.json'):
                    with open(config_path, 'r') as f:
                        user_config = json.load(f)
                else:
                    # Try JSON first, then YAML if available
                    try:
                        with open(config_path, 'r') as f:
                            user_config = json.load(f)
                    except:
                        if HAS_YAML:
                            with open(config_path, 'r') as f:
                                user_config = yaml.safe_load(f)
                        else:
                            raise ValueError("Could not parse config file")

                # Merge with defaults
                config_data = cls._merge_configs(config_data, user_config)
            except Exception as e:
                print(f"Warning: Could not load config file {config_path}: {e}")
                print("Using default configuration.")

        # Validate and create Config object
        try:
            config = Config(**config_data)

            # --- START Validation for max_workers ---
            import psutil
            physical_cores = psutil.cpu_count(logical=False) if psutil else None

            if physical_cores:
                max_workers_set = config.parallel.get('max_workers', 0)
                if max_workers_set > physical_cores:
                    import logging
                    logger = logging.getLogger(__name__)
                    logger.warning(
                        f"Configured max_workers ({max_workers_set}) exceeds system physical cores ({physical_cores}). "
                        "The system may become unresponsive. It is recommended to leave at least one core free."
                    )
            # --- END Validation for max_workers ---

            # Store the config path for saving
            config._config_path = config_path
            return config
        except ValueError as e:
            raise ValueError(f"Configuration validation failed: {e}")

    @classmethod
    def save_default_config(cls, output_path: str) -> None:
        """
        Save the default configuration to a file.

        Args:
            output_path: Where to save the config file
        """
        if HAS_YAML and output_path.endswith(('.yaml', '.yml')):
            with open(output_path, 'w') as f:
                yaml.dump(cls.DEFAULT_CONFIG, f, default_flow_style=False, sort_keys=False)
        elif output_path.endswith('.json'):
            # JSON format
            with open(output_path, 'w') as f:
                json.dump(cls.DEFAULT_CONFIG, f, indent=2)
        else:
            # Default to JSON
            with open(output_path, 'w') as f:
                json.dump(cls.DEFAULT_CONFIG, f, indent=2)

        # Add header comment if it's a file that supports comments
        if output_path.endswith(('.yaml', '.yml')) or (not HAS_YAML and output_path.endswith('.json')):
            with open(output_path, 'r') as f:
                content = f.read()

            header = """
# =====================================================================
# PocketTTS Configuration File
# =====================================================================
#
# This file contains all configuration settings for PocketTTS.
# Modify values here to customize behavior.
#
# Units:
# - Durations: milliseconds (ms)
# - Sample rates: Hz
# - Quality levels: 1-4 (higher = better quality, slower)
#
# =====================================================================

"""
            with open(output_path, 'w') as f:
                f.write(header + content)

    @classmethod
    def _merge_configs(cls, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """
        Deep merge override config into base config.

        Args:
            base: Base configuration
            override: User overrides

        Returns:
            Merged configuration
        """
        result = base.copy()

        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                # Deep merge dictionaries
                result[key] = cls._merge_configs(result[key], value)
            else:
                # Override or add new value
                result[key] = value

        return result

    @classmethod
    def get_config_paths(cls) -> List[str]:
        """
        Get possible config file locations in order of priority.

        Returns:
            List of possible config file paths
        """
        paths = []

        # Current directory
        paths.append('./audiobook_config.yaml')
        paths.append('./config.yaml')

        # User's home directory
        home = Path.home()
        paths.append(str(home / '.audiobook_config.yaml'))
        paths.append(str(home / '.config' / 'pocket_tts' / 'config.yaml'))

        return paths

    @classmethod
    def find_config(cls) -> Optional[str]:
        """
        Find the first available config file.

        Returns:
            Path to config file, or None if none found
        """
        for path in cls.get_config_paths():
            if os.path.exists(path):
                return path
        return None
